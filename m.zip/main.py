from tkinter import *
from KEEpydb import KEEpydb
#from PIL import ImageTk, Image
import time

class main:
        def __init__(self,root):
                #imAGES
               # self.nxtbutton=ImageTk.PhotoImage(Image.open('assets\\nxtbutton.png').resize((150,50), Image.ANTIALIAS))
                self.root=root
                self.query=KEEpydb.query('pipdb','pipdb','12345678')
                self.query.save()
                self.root.config(bg='white')
                self.height=500
                self.width=700
                self.root.geometry(f'{self.width}x{self.height}+0+0')
                self.root.resizable(False,False)
                self.root.title('upload pip')
                self.introSCREEN()
		
        def introSCREEN(self):
                self.query.update('b2',str(time.asctime()))
                self.query.save()
                Label(self.root,
                      text='UPLOAD PIP',font='verdana 20 bold',
                      bg='white',fg='blue').place(x=100,y=200)
                self.Home()
                
        def Home(self):
                        frame=Frame(self.root,bg='grey20',height=self.height,width=self.width).place(x=0,y=0)
                        Label(frame,
                              text='Enter Package Name -',
                              bg='grey20',fg='dodger blue',font='verdana 15 bold').place(x=130,y=200)
                        packagename=StringVar()
                        Entry(frame,textvariable=packagename).place(x=133,y=233,width=400,height=30)
                        Button(frame,text='NEXT',bg='forest green',fg='white',padx=173,font='verdana',command=self.OnClickNext).place(x=133,y=270)

        def OnClickNext(self):
                f=Frame(self.root,bg='grey20',height=self.height,width=self.width).place(x=0,y=0)
                Label(f,bg='grey20',fg='white',text='Setup.py',font='verdana 15 bold').place(x=20,y=20)
                Text(f).place(x=20,y=25,width=600,height=300)

	
if __name__=='__main__':
        root=Tk()
        main(root)
        root.mainloop()
